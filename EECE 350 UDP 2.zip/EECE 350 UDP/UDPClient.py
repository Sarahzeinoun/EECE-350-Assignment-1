import time
import socket

addr= input("Enter the host IP: ")
port= input("Enter the port used: ")

sum1=0

client_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_address=(host,port)


for i in range (5):
    init_time = time.time()
    client_sock.sendall("Test Message")
     data = sock.recvfrom(2048)

     end_time= time.time()
     travel_time= str(end_time - init_time)
     print ("The roundtrip time (RTT) is: ", travel_time)

     sum1+=float(travel_time)
     print("Received", repr(data))
    
    
average= sum1/5
print ('Average RTT is:' , average , "  s")
