import socket
from datetime import datetime
import time

addr="127.0.0.2'
port=12345

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind((addr,port))
s.listen()

while True:
    intit_time= time.time()
    data=sock.recvfrom(1024)
    if not data:
        break

    print("Recieved request at ", datetime.now())
    sent = sock.sendto(data, address)
    travel_time= str(end_time - init_time)
    print("The roundtrip time (RTT) is: ", travel_time)
          



